# Invitación original con carta de apertura

Se conservaron los colores, el diseño y las ilustraciones incluidas. Se añadieron contador, iconos SVG, música y una carta que se abre al pulsarla. También se puede abrir sin música y pausar la melodía.

## Instalación
Copia invitacion.html, css/detalles-boda.css, js/detalles-boda.js, js/invitacion.js y audio/nuestro-comienzo.wav al proyecto existente, manteniendo las carpetas.
Conserva tu js/config.js real: el archivo de tus adjuntos contiene valores de ejemplo de Supabase.
Conserva tu carpeta img con fotiito.png, novia.png, novio.png y qr3.jpeg. Esas imágenes no estaban adjuntas. Se mantienen las rutas y las flores originales; los novios tienen ilustraciones incluidas como alternativa si sus PNG no cargan.

## Ajustes
El contador está en js/detalles-boda.js, variable FECHA_BODA: 28/11/2026, 14:00, Bolivia.
La melodía instrumental original dura 38 segundos y se repite. Puedes cambiar el src del elemento wedding-audio para usar otra canción.
El modo #editar omite la carta para facilitar los ajustes.

## Comprobaciones
JavaScript revisado, IDs sin duplicados y colores originales comprobados. No se pudo realizar una revisión visual en navegador. La confirmación de asistencia requiere tu configuración y las funciones RPC existentes de Supabase.
